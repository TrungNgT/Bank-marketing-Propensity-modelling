from __future__ import annotations

from io import BytesIO
from pathlib import Path
from bs4 import BeautifulSoup
from docx import Document
from docx.oxml.ns import qn



def parse_docx(path: Path) -> str:
    """
    Convert DOCX to semantic HTML suitable for downstream
    structure-aware chunking and retrieval.

    Preserves:
      - paragraphs
      - tables
      - nested tables
      - internal hyperlinks
      - strikethrough information
      - source locations
    """
    from docxhtml_converter.docxhtml import get_html_from_docx_binary

    with path.open("rb") as f:
        html = get_html_from_docx_binary(BytesIO(f.read()))

    soup = BeautifulSoup(html, "lxml")

    # Add our own semantic annotations.
    _annotate_tables(soup)
    _annotate_internal_links(soup)
    _annotate_strikethrough(soup)

    return str(soup)

def _annotate_tables(soup: BeautifulSoup) -> None:
    """
    Add stable IDs to HTML tables and cells.

    Example:
        table-0
        table-0-row-12-cell-1
    """

    for table_idx, table in enumerate(soup.find_all("table")):
        table["data-table-id"] = f"table-{table_idx}"

        for row_idx, row in enumerate(table.find_all("tr", recursive=False)):
            row["data-row-index"] = str(row_idx)

            cells = row.find_all(["td", "th"], recursive=False)

            for col_idx, cell in enumerate(cells):
                cell["data-cell-id"] = (
                    f"table-{table_idx}"
                    f"-row-{row_idx}"
                    f"-cell-{col_idx}"
                )

def _annotate_internal_links(soup: BeautifulSoup) -> None:
    """
    Annotate internal hyperlinks in the HTML produced from DOCX.

    Looks for `<a href="#...">` or `<a name="...">` and adds
    `data-internal-anchor` and `data-internal-text` attributes so
    downstream code can locate and reference in-document anchors.
    """

    for a in soup.find_all("a"):
        href = a.get("href") or ""
        name = a.get("name")
        if href.startswith("#") or name:
            anchor = href[1:] if href.startswith("#") else name
            text = a.get_text(strip=True)
            a["data-internal-anchor"] = anchor
            if text:
                a["data-internal-text"] = text


def _annotate_strikethrough(soup: BeautifulSoup) -> None:
    """
    Annotate HTML elements that represent strikethrough text so downstream
    processors can preserve that formatting information.
    """

    # Elements that explicitly represent strike-through
    for el in soup.find_all(["s", "strike"]):
        el["data-strikethrough"] = "true"

    # Inline styles that include `line-through`
    for el in soup.find_all(True):
        style = el.get("style", "") or ""
        if "line-through" in style:
            el["data-strikethrough"] = "true"

def extract_internal_links(doc: Document) -> list[dict]:
    """
    Extract Word internal hyperlinks.

    Returns:
        [
            {
                "anchor": "...",
                "text": "...",
            }
        ]
    """

    links = []

    for paragraph in _iter_all_paragraphs(doc):
        for hyperlink in paragraph._p.findall(qn("w:hyperlink")):
            anchor = hyperlink.get(qn("w:anchor"))

            if not anchor:
                continue

            # Collect text from `w:t` nodes under the hyperlink element.
            text_parts: list[str] = []
            for node in hyperlink.iter():
                if node.tag == qn("w:t") and (node.text):
                    text_parts.append(node.text)

            text = "".join(text_parts)

            links.append({
                "anchor": anchor,
                "text": text,
            })

    return links

def _iter_all_paragraphs(doc: Document):
    """Yield paragraphs recursively, including nested table cells."""

    for paragraph in doc.paragraphs:
        yield paragraph

    for table in doc.tables:
        yield from _iter_table_paragraphs(table)


def _iter_table_paragraphs(table):
    for row in table.rows:
        for cell in row.cells:

            for paragraph in cell.paragraphs:
                yield paragraph

            for nested_table in cell.tables:
                yield from _iter_table_paragraphs(nested_table)

def extract_bookmarks(doc: Document) -> dict[str, int]:
    """
    Return bookmark name -> bookmark ID.
    """

    result = {}

    for element in doc.element.body.iter():
        if element.tag != qn("w:bookmarkStart"):
            continue

        name = element.get(qn("w:name"))
        bookmark_id = element.get(qn("w:id"))

        if name and bookmark_id:
            result[name] = int(bookmark_id)

    return result

def run_is_struck(run) -> bool:
    """
    True when the run explicitly has strikethrough formatting.
    """
    return run.font.strike is True

def paragraph_segments(paragraph) -> list[dict]:
    segments = []

    for run in paragraph.runs:
        text = run.text

        if not text:
            continue

        segments.append({
            "text": text,
            "strikethrough": run_is_struck(run),
        })

    return segments

