from dataclasses import dataclass, field
from bs4 import BeautifulSoup


@dataclass
class HtmlChunk:
    chunk_id: str
    html: str
    text: str
    status: str = "active"
    source_cell: str | None = None
    related_chunks: list[str] = field(default_factory=list)

def chunk_html(
    html: str,
    max_chars: int = 6000,
) -> list[HtmlChunk]:

    soup = BeautifulSoup(html, "lxml")

    chunks: list[HtmlChunk] = []

    # ---------------------------------------------------------
    # 1. Standalone paragraphs
    # ---------------------------------------------------------

    for idx, paragraph in enumerate(
        soup.find_all(["p", "h1", "h2", "h3", "h4", "h5", "h6"])
    ):
        # Ignore paragraphs inside tables.
        if paragraph.find_parent("table"):
            continue

        text = paragraph.get_text(" ", strip=True)

        if not text:
            continue

        chunks.append(
            HtmlChunk(
                chunk_id=f"paragraph-{idx}",
                html=str(paragraph),
                text=text,
            )
        )

    # ---------------------------------------------------------
    # 2. Top-level tables
    # ---------------------------------------------------------

    for table_idx, table in enumerate(
        soup.find_all("table")
    ):

        # Don't process nested table independently here.
        if table.find_parent("table"):
            continue

        chunks.extend(
            _chunk_table(
                table,
                table_idx,
                max_chars,
            )
        )

    _resolve_relationships(chunks)

    return chunks

def _chunk_table(
    table,
    table_idx: int,
    max_chars: int,
) -> list[HtmlChunk]:

    chunks = []

    rows = table.find_all("tr", recursive=False)

    for row_idx, row in enumerate(rows):

        cells = row.find_all(
            ["td", "th"],
            recursive=False,
        )

        if not cells:
            continue

        cell_texts = [
            cell.get_text(" ", strip=True)
            for cell in cells
        ]

        text = "\n\n".join(
            f"Column {i + 1}:\n{cell_text}"
            for i, cell_text in enumerate(cell_texts)
            if cell_text
        )

        if not text:
            continue

        row_html = str(row)

        # If this row is small enough, keep it together.
        if len(text) <= max_chars:

            chunks.append(
                HtmlChunk(
                    chunk_id=f"table-{table_idx}-row-{row_idx}",
                    html=row_html,
                    text=text,
                    source_cell=(
                        cells[0].get("data-cell-id")
                        if cells else None
                    ),
                )
            )

        else:
            # Oversized row:
            # chunk individual cells.
            for col_idx, cell in enumerate(cells):

                cell_text = cell.get_text(
                    " ",
                    strip=True,
                )

                if not cell_text:
                    continue

                chunks.append(
                    HtmlChunk(
                        chunk_id=(
                            f"table-{table_idx}"
                            f"-row-{row_idx}"
                            f"-cell-{col_idx}"
                        ),
                        html=str(cell),
                        text=cell_text,
                        source_cell=cell.get(
                            "data-cell-id"
                        ),
                    )
                )

    return chunks

def _resolve_relationships(
    chunks: list[HtmlChunk],
) -> None:

    by_id = {
        chunk.source_cell: chunk
        for chunk in chunks
        if chunk.source_cell
    }

    for chunk in chunks:

        soup = BeautifulSoup(
            chunk.html,
            "lxml",
        )

        for link in soup.select(
            "[data-internal-ref]"
        ):

            target = link["data-internal-ref"]

            target_chunk = by_id.get(target)

            if target_chunk:
                chunk.related_chunks.append(
                    target_chunk.chunk_id
                )

