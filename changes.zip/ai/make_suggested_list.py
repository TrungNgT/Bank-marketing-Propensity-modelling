"""Generate scoped, evidence-backed audit findings in three LLM stages."""
from __future__ import annotations

import json
import logging
import time
from typing import Any

import anthropic

from app.ai.client import LLMResult, call_json
from app.ai.issues_schema import (
    InScopePI,
    OutOfScopePI,
    PotentialIssue,
    SuggestedIssue,
)

LOGGER = logging.getLogger(__name__)

_POTENTIAL_SYSTEM = (
    "You are an internal audit finding analyst. Reformulate only the "
    "potential findings supported by SOURCE_OF_TRUTH. Do not invent facts."
)
_POTENTIAL_USER = """<SOURCE_OF_TRUTH>
{source_of_truth}
</SOURCE_OF_TRUTH>

Return a JSON array of objects matching PotentialIssue:
[{{"title_hint": "...", "description": "...", "riskLevel": "Low|Medium|High"}}]
Return JSON only."""

_SCOPE_SYSTEM = (
    "You are an internal audit scope reviewer. Classify each potential issue "
    "strictly against SCOPE_CONTEXT and explain every out-of-scope decision."
)
_SCOPE_USER = """<SCOPE_CONTEXT>
{scope_context}
</SCOPE_CONTEXT>

<POTENTIAL_ISSUES>
{potential_issues}
</POTENTIAL_ISSUES>

Return one JSON object with these arrays:
{{
  "in_scope": [{{"title_hint": "...", "description": "...", "riskLevel": "Low|Medium|High"}}],
  "out_of_scope": [{{"title_hint": "...", "description": "...", "riskLevel": "Low|Medium|High", "reason": "...", "reference_doc": "..."}}]
}}
Return JSON only."""

_SUGGESTED_SYSTEM = (
    "You are an internal audit issue drafter. Turn only the in-scope issues "
    "into evidence-backed suggested issues. Do not infer facts, references, "
    "or SOP requirements absent from the supplied contexts."
)
_SUGGESTED_USER = """<SCOPE_CONTEXT>
{scope_context}
</SCOPE_CONTEXT>

<IN_SCOPE_ISSUES>
{in_scope_issues}
</IN_SCOPE_ISSUES>

<EVIDENCE_CONTEXT>
{evidence_context}
</EVIDENCE_CONTEXT>

Return a JSON array matching SuggestedIssue:
[{{"title_hint": "...", "description": "...", "evidence_summary": "...",
"evidence_reference": "...", "sop_reference": "...", "process_name": "...",
"riskLevel": "Low|Medium|High", "riskCategory": "..."}}]
Use only evidence and references present in EVIDENCE_CONTEXT. Return JSON only."""


def _log_call(stage: str, started_at: float, result: LLMResult) -> None:
    LOGGER.info(
        "suggested_findings.%s input_tokens=%d cached_input_tokens=%d "
        "output_tokens=%d elapsed_seconds=%.3f",
        stage,
        result.input_tokens,
        result.cached_input_tokens,
        result.output_tokens,
        time.perf_counter() - started_at,
    )


def _call_stage(
    client: anthropic.Anthropic,
    model: str,
    stage: str,
    system: str,
    user: str,
    *,
    max_tokens: int,
    temperature: float,
) -> Any:
    started_at = time.perf_counter()
    result = call_json(
        client,
        model=model,
        system=system,
        user=user,
        max_tokens=max_tokens,
        temperature=temperature,
    )
    _log_call(stage, started_at, result)
    return result.data


def generate_suggested_findings(
    client: anthropic.Anthropic,
    model: str,
    source_of_truth: str,
    scope_context: str,
    evidence_context: str,
) -> list[SuggestedIssue]:
    """Run potential-finding, scope-review, and evidence-drafting stages."""
    potential_data = _call_stage(
        client,
        model,
        "potential",
        _POTENTIAL_SYSTEM,
        _POTENTIAL_USER.format(source_of_truth=source_of_truth),
        max_tokens=4096,
        temperature=0.2,
    )
    potential_issues = [PotentialIssue.model_validate(item) for item in potential_data]

    scope_data = _call_stage(
        client,
        model,
        "scope",
        _SCOPE_SYSTEM,
        _SCOPE_USER.format(
            scope_context=scope_context,
            potential_issues=json.dumps(
                [issue.model_dump() for issue in potential_issues], indent=2
            ),
        ),
        max_tokens=4096,
        temperature=0.1,
    )
    in_scope = [InScopePI.model_validate(item) for item in scope_data["in_scope"]]
    _ = [OutOfScopePI.model_validate(item) for item in scope_data["out_of_scope"]]

    suggested_data = _call_stage(
        client,
        model,
        "suggested",
        _SUGGESTED_SYSTEM,
        _SUGGESTED_USER.format(
            scope_context=scope_context,
            in_scope_issues=json.dumps(
                [issue.model_dump() for issue in in_scope], indent=2
            ),
            evidence_context=evidence_context,
        ),
        max_tokens=6144,
        temperature=0.2,
    )
    return [SuggestedIssue.model_validate(item) for item in suggested_data]