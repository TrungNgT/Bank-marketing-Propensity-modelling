from __future__ import annotations
from typing_extensions import Literal
from pydantic import BaseModel, Literal

class PotentialIssue(BaseModel):
    """A reformulated potential issue by the AI, based on potential risks from PU files"""
    title_hint: str
    description: str
    riskLevel: Literal["Low", "Medium", "High"]

class InScopePI(PotentialIssue):
    pass

class OutOfScopePI(PotentialIssue):
    reason: str  # why it's out of scope
    reference_doc: str  # reference document or source for the out-of-scope issue

class SuggestedIssue(BaseModel):
    title_hint: str
    description: str
    evidence_summary: str  # evidence or context for the suggested issue
    evidence_reference: str  # reference to the evidence or source document
    sop_reference: str  # reference to the relevant SOP or guideline
    process_name: str  # name of the process or area related to the suggested issue
    riskLevel: Literal["Low", "Medium", "High"]
    riskCategory: str  # category of risk (e.g., operational, compliance, financial)